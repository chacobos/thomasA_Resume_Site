$(document).ready(function(){
	$(".menu").load("menu.html");
})
